#The boxfit volumetric fit algorithm

A fitting algorithm that accounts for large resolution uncertainities in detector resolution, effectively creating a "hit" that is a 3D volume of equal likelihood rather than a point with tradiontional uncertainties
